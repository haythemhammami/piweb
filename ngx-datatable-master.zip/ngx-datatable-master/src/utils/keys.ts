export enum Keys {
  up = 38,
  down = 40,
  return = 13,
  escape = 27,
  left = 37,
  right = 39
}
