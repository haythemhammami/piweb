export enum ClickType {
  single = 'single' as any,
  double = 'double' as any  
}
