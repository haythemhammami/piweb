export enum SortType {
  single = 'single' as any,
  multi = 'multi' as any
}
