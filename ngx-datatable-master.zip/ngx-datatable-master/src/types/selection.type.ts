export enum SelectionType {
  single = 'single' as any,
  multi = 'multi' as any,
  multiClick = 'multiClick' as any,
  cell = 'cell' as any,
  checkbox = 'checkbox' as any
}
