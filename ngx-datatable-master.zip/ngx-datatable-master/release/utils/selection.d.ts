export declare function selectRows(selected: any[], row: any, comparefn: any): any[];
export declare function selectRowsBetween(selected: any[], rows: any[], index: number, prevIndex: number, comparefn: any): any[];
