import 'rxjs/add/observable/fromEvent';
export declare class NgxDatatableModule {
}
