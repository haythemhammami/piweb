import { TemplateRef } from '@angular/core';
export declare class DataTableColumnHeaderDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
}
