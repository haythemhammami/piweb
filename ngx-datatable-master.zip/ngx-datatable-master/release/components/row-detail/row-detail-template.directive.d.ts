import { TemplateRef } from '@angular/core';
export declare class DatatableRowDetailTemplateDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
}
