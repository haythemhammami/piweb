export * from './row-detail.directive';
export * from './row-detail-template.directive';
