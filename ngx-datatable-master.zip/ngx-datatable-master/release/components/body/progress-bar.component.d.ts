export declare class ProgressBarComponent {
}
