"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=table-column.type.js.map