export declare enum SortDirection {
    asc,
    desc,
}
