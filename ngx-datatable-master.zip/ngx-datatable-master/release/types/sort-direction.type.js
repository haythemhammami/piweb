"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SortDirection;
(function (SortDirection) {
    SortDirection[SortDirection["asc"] = 'asc'] = "asc";
    SortDirection[SortDirection["desc"] = 'desc'] = "desc";
})(SortDirection = exports.SortDirection || (exports.SortDirection = {}));
//# sourceMappingURL=sort-direction.type.js.map