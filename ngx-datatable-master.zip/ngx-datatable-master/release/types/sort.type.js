"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SortType;
(function (SortType) {
    SortType[SortType["single"] = 'single'] = "single";
    SortType[SortType["multi"] = 'multi'] = "multi";
})(SortType = exports.SortType || (exports.SortType = {}));
//# sourceMappingURL=sort.type.js.map