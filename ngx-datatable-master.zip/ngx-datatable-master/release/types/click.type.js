"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ClickType;
(function (ClickType) {
    ClickType[ClickType["single"] = 'single'] = "single";
    ClickType[ClickType["double"] = 'double'] = "double";
})(ClickType = exports.ClickType || (exports.ClickType = {}));
//# sourceMappingURL=click.type.js.map