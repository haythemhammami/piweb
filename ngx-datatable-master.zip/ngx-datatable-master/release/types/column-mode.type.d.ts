export declare enum ColumnMode {
    standard,
    flex,
    force,
}
