# Row Detail Outputs
All outputs are Angular2 `EventEmitter`ers.

### `toggle`
Row detail row was toggled.

```
{
  type: 'all' || 'row'
  value: boolean || row object
}
```
