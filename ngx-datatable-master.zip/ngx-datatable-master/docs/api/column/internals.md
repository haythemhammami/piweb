# Column Internals

## Ids
Each row is decorated with a `$$id` attribute. This allows us to track the column
for faster change detection/etc.
