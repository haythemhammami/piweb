import 'core-js/es6';
import 'core-js/es7/reflect';
import 'zone.js/dist/zone';

// angular
import '@angular/platform-browser';
import '@angular/core';
import '@angular/platform-browser-dynamic';
import '@angular/common';

// RxJS
import 'rxjs/Rx';
